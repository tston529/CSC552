/**
 * infoTable is a GUI application which queries the ODN RWJF Health Behaviors
 * public statistics database and returns data related to the queries the
 * user specified.
 */
package infoTable;